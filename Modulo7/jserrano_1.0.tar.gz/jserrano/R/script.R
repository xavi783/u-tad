
jserrano.version <- function(){
  sprintf("Version 0.0.1 - Paquete hecho por JSerrano")
}

greetings <- function(name){
  sprintf("Saludos %s",name)
}